<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="<?php echo e(mix('/css/app.css'), false); ?>">
    <title>证书管理系统</title>
</head>
<body class="position-relative">
<div id="app">

</div>
<div class="my-3 text-center w-100 font-weight-bolder">
    Designed By <a href="http://jialidun.vip">Jianwi</a>@2020
</div>
<script !src="">
    const APP_URL = '<?php echo e(config('app.url'), false); ?>'
    // console.log(APP_URL)
</script>
<script src="<?php echo e(mix('/js/main.js'), false); ?>"></script>
</body>
</html>
<?php /**PATH A:\phpstudy_pro\WWW\certificate-manage.test\laravel\resources\views/app.blade.php ENDPATH**/ ?>