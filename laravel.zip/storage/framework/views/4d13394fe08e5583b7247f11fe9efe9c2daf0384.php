<div class="input-group input-group-sm">
    <input <?php echo $attributes; ?> placeholder="<?php echo e($label, false); ?>"/>
</div><?php /**PATH A:\phpstudy_pro\WWW\certificate-manage.test\laravel\vendor\encore\laravel-admin\src/../resources/views/grid/quick-create/text.blade.php ENDPATH**/ ?>