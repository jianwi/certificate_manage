<?php if($help): ?>
<span class="help-block">
    <i class="fa <?php echo e(\Illuminate\Support\Arr::get($help, 'icon'), false); ?>"></i>&nbsp;<?php echo \Illuminate\Support\Arr::get($help, 'text'); ?>

</span>
<?php endif; ?><?php /**PATH /media/dujianjun/software/phpstudy_pro/WWW/certificate-manage.test/laravel/vendor/encore/laravel-admin/src/../resources/views/form/help-block.blade.php ENDPATH**/ ?>