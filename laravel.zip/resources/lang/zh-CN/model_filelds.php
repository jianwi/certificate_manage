<?php
return [
    'Activity id' => '活动名称',
    'Created at' => '创建时间',
    'Updated at' => '更新时间'
];
