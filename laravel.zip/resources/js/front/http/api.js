export default {
    // 证书
    Certificates: {
        index: '/certificates',
    },

}
