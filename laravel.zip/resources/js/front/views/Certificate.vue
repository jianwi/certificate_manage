<template>
<certificate-info></certificate-info>
</template>

<script>
    import CertificateInfo from "../ component/CertificateInfo";
    export default {
        name: "Certificate",
        components: {CertificateInfo}
    }
</script>

<style scoped>

</style>
