<template>
    <div>
      <h1>e得到</h1>
      <h2></h2>

    </div>
</template>


<script>
    export default {
        name: "Test"
    }
</script>

<style scoped>

</style>
