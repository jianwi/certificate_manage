<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="{{ mix('/css/app.css') }}">
    <title>证书管理系统</title>
</head>
<body class="position-relative">
<div id="app">

</div>
<div class="my-3 text-center w-100 font-weight-bolder">
    Designed By <a href="http://jialidun.vip">Jianwi</a>@2020
</div>
<script !src="">
    const APP_URL = '{{ config('app.url') }}'
    // console.log(APP_URL)
</script>
<script src="{{ mix('/js/main.js') }}"></script>
</body>
</html>
